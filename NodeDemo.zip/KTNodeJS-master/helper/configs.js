module.exports= {
    SECRET_KEY:"heheheehe",
    EXP: '20d'
}